import java.util.Scanner;

public class Main {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            //UNIVERSIDAD
            System.out.println("Ingrese el nombre de la Universidad: ");
            String nombreUniversidad = scanner.nextLine();
            System.out.println("Ingrese el ID: ");
            String nombreID = scanner.nextLine();
            Universidad universidad = new Universidad(nombreUniversidad,nombreID);
            //System.out.println(universidad.detalleU());

            //ESTUDIANTE
            System.out.println("Ingrese el nombre del estudiante: ");
            String nombreEstudiante = scanner.nextLine();
            System.out.println("Ingrese la carrera del estudiante: ");
            String carrera = scanner.nextLine();
            System.out.println("Ingrese el correo del estudiante: ");
            String correo = scanner.nextLine();
            Estudiantes estudiantes = new Estudiantes(nombreEstudiante,carrera,correo);
            //System.out.println(estudiantes.detalleE());

            //MATERIAS
            System.out.println("Ingrese la primera materias: ");
            String mat1= scanner.nextLine();
            System.out.println("Ingrese la segundo materias: ");
            String mat2= scanner.nextLine();
            System.out.println("Ingrese la tercera materias: ");
            String mat3= scanner.nextLine();
            Materia materia = new Materia(mat1,mat2,mat3);
            //System.out.println(materia.detalleM());

            //CURSOS
            System.out.println("Numero de curso 1: ");
            String curso1 = scanner.nextLine();
            System.out.println("Numero de curso 2: ");
            String curso2 = scanner.nextLine();
            System.out.println("Numero de curso 3: ");
            String curso3 = scanner.nextLine();
            Curso curso = new Curso(curso1,curso2,curso3);
            //System.out.println(curso.detallC());


            System.out.println("INFORMACIÓN ACADEMICA"+"\n"+universidad.detalleU());
            System.out.println(estudiantes.detalleE());
            System.out.println(materia.detalleM());
            System.out.println(curso.detallC());

        }

}