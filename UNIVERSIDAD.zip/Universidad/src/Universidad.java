public class Universidad {
    private String nombre;
    private String Id;

    public Universidad() {
    }

    public Universidad(String nombre) {
        this.nombre = nombre;
    }

    public Universidad(String nombre, String id) {
        this.nombre = nombre;
        Id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String detalleU(){
        String u = "Universidad: "+this.nombre+ "\n"+"El ID es: "+this.Id+"\n";
        return u;
    }
}
