public class Estudiantes {
    private String Nombre;
    private String Carrera;
    private  String Correo;

    public Estudiantes() {
    }

    public Estudiantes(String nombre) {
        Nombre = nombre;
    }

    public Estudiantes(String nombre, String carrera) {
        Nombre = nombre;
        Carrera = carrera;
    }

    public Estudiantes(String nombre, String carrera, String correo) {
        Nombre = nombre;
        Carrera = carrera;
        Correo = correo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String carrera) {
        Carrera = carrera;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String detalleE(){
        String e = "Nombre: "+this.Nombre+"\n"+"Carrera: "+this.Carrera+"\n"
                +"Correo: "+this.Correo+"\n";
        return e;
    }
}
