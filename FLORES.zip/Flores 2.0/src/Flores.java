public class Flores {
    private String color;
    private String tipo;
    private String olor;
    private String forma;

    //Con set se asgina los valores y se toma como prioridad lo declarado con el set

    //Contructores y Destructores
    //Un constructor crea un espacio de memoria para los objetos

    public String getColor() {
        return color;
    }

    public String getTipo() {
        return tipo;
    }

    public String getOlor() {
        return olor;
    }

    public String getForma() {
        return forma;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setOlor(String olor) {
        this.olor = olor;
    }

    public void setForma(String forma) {
        this.forma = forma;
    }

    public String detalleflores(){
        //Metodos propios del programador

        String gt = "El color es: "+ this.color +"\n"+
                "El tipo es: "+this.tipo+"\n"+"El olor es: "+ this.olor+"\n"+
                "Su forma es: "+this.forma;
        return gt;

    }
}
