 public class Main {
     public static void main(String[] args) {
         Flores rosas = new Flores();
         //Tienes que acceder a los atributos con tus metodos
         // Usando los setters para asignar valores
         rosas.setColor("Rojo");
         rosas.setOlor("Afrutado");
         rosas.setForma("Ovaladas");
         rosas.setTipo("Rosas");

         // Usando los getters para obtener los valores
         System.out.println("FLORES");
         System.out.println("Color: " + rosas.getColor());
         System.out.println("Olor: " + rosas.getOlor());
         System.out.println("Forma: " + rosas.getForma());
         System.out.println("Tipo: " + rosas.getTipo());

         //Sirve al usar el metodo detalleflores()
         //System.out.println("FLORES:"+"\n"+ rosas.detalleflores());
     }
 }